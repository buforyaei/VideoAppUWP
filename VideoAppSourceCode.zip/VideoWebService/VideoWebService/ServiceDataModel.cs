﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VideoWebService
{
    public class ServiceDataModel
    {
        public string Port { get; set; }
        public bool IsOccupied { get; set; }
    }
}
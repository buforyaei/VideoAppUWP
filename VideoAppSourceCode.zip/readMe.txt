W Folderze CamTest, nieszcz�nie nazwanym, znajduje si� aplikacja klient i serwer w jednej solucji. 
Folder VideoWebService to pliki odpowiedzialne za serwis pomocniczy postawiony na Azure.
Pozdrawiam